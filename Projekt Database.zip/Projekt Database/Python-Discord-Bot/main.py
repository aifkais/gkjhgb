
import os

#from Fight import getData, linetoArr
from KaderTemplate import showTemplate
from Game_Init import gameinit
from Game_Init import initTrainer
from Game_Init import initPokemontoTrainer
from Utility import asp, asp2
from Spieltag import spieltag, rr2, spieltag2, aufabstieg, getsortettable,sortierfunktion
from FrontEnd import showprofile, gethelp
from Fight import getday, change, resetseason, incday, incday2,blockPrint, enablePrint








def change1(msg):
  change(msg,"347156882374262795")
  table = ""
  table = showprofile("347156882374262795",table)
  print(table)

def on_message(msg):
  if msg.author == bot.user:
    return



  if (msg.author.id in idsammlung and msg.content.startswith("show")):
    table = ""
    table = showprofile(msg.author.id, table)
    print(table)

  if (msg.author.id in idsammlung and msg.content.startswith("help")):
    table = ""
    table = gethelp(table)
    print(table)

  if msg.author.id == tonyid and msg.content.startswith("start_Game"):
    day = int(getday())
    print(day)
    if day < 30:
      gameday()
    else:
      siegerehrung()
      aufabstieg()
      resetseason()

  if msg.author.id == tonyid and msg.content.startswith("reset_Game"):
    resetseason()



  #if msg.author.id == 347156882374262795 and (msg.content.startswith("get") or msg.content.startswith("scout")):





def start_Game():
    day = int(getday())
    print("starte Spieltag: " + str(day+1))

    if day < 30:
      gameday()
    else:
      siegerehrung()
      aufabstieg()
      resetseason()


def siegerehrung():
  table = []
  table = getsortettable()
  table1 = ""
  table1 += "1. Pokemonmeister ist " + table[0][0] + " mit " + table[0][
      6] + "\n"
  table1 += "Glückwunsch an " + table[0][0] + "\n\n"
  table1 += "Zweiter Platz der 1.Liga ist " + table[1][0] + " mit " + table[1][
      6] + "\n"
  table1 += "Glückwunsch an " + table[1][0] + "\n\n"
  table1 += "2. Pokemonmeister ist " + table[10][0] + " mit " + table[10][
      6] + "\n"
  table1 += "Glückwunsch an " + table[10][0] + "\n\n"
  table1 += "Zweiter Platz der 2.Liga ist " + table[11][0] + " mit " + table[
      11][6] + "\n"
  table1 += "Glückwunsch an " + table[11][0] + "\n\n"

  table1 += table[10][0] + " und " + table[11][
      0] + " steigen in die Erste Liga auf\n\n"
  table1 += table[20][0] + " und " + table[21][
      0] + " steigen in die Zweite Liga auf\n\n"
  table1 += table[9][0] + " und " + table[8][
      0] + " steigen in die Zweite Liga ab\n\n"
  table1 += table[19][0] + " und " + table[18][
      0] + " steigen in die Dritte Liga ab\n\n"

  print(table1)

def gameday():

  day = 0
  day = int(getday())
  print(day)
  a1 = 12
  a2 = 4
  f = 20
  f2 = 8
  f3 = 16
  table1 = []
  table2 = []
  table3 = []
  spielergen1 = []
  spielergen2 = []
  spielergen3 = []
  pkmgen1 = []
  pkmgen2 = []
  pkmgen3 = []
  pastresults11 = []
  pastresults12 = []
  pastresults13 = []
  pastresults21 = []
  pastresults22 = []
  pastresults31 = []
  pastresults32 = []
  pastresults33 = []
  table1, spielergen1, pastresults11, pastresults12, pastresults13 = spieltag(
      day + 1)
  print(table1)
  table1 = sorted(table1, key=sortierfunktion)


  if len(table1) != 0:
    table = "```\n"  # Anfang des Code-Blocks
    if day + 1 in [7, 8, 9, 10, 17, 18, 19, 20, 27, 28, 29, 30]:
      if day + 1 in [7, 17, 27]:
        table += "TRANSFERTAG: " + str(1) + " von 4\n"
      elif day + 1 in [8, 18, 28]:
        table += "TRANSFERTAG: " + str(2) + " von 4\n"
      elif day + 1 in [9, 19, 29]:
        table += "TRANSFERTAG: " + str(3) + " von 4\n"
      elif day + 1 in [10, 20, 20]:
        table += "TRANSFERTAG: " + str(4) + " von 4\n"

    table += asp(str("# "), 2) + asp("TrainerName", a1) + " " + asp(
        "Win", a2) + " " + asp("Lose", a2) + " " + asp(
            "StatSum", a2) + " Totaldmg " + "\n"  # Kopfzeile
    for i in range(10):
      table += asp(str(i + 1), 2) + " " + asp(table1[i][0], a1) + " " + asp(
          str(table1[i][1]), a2) + " " + asp(str(
              table1[i][2]), a2) + " " + asp(
                  str(table1[i][4]), a2 + 3) + " " + asp(
                      str(table1[i][3]),
                      a2 + 2) + "  " + table1[i][6] + "\n"  # Kopfzeile
    table += "```"  # Ende des Code-Blocks
    print(table)
    if len(table1) != 0:
      table = "```\n"  # Anfang des Code-Blocks
      table += asp(str("# "), 2) + asp("TrainerName", a1) + " " + asp(
          "Win", a2) + " " + asp("Lose", a2) + " " + asp(
              "StatSum", a2) + "\n"  # Kopfzeile
      for i in range(10):
        table += asp(
            str(i + 1), 2) + " " + asp(table1[i + 10][0], a1) + " " + asp(
                str(table1[i + 10][1]),
                a2) + " " + asp(str(table1[i + 10][2]), a2) + " " + asp(
                    str(table1[i + 10][4]), a2 + 3) + " " + asp(
                        str(table1[i + 10][3]),
                        a2 + 2) + "  " + table1[i + 10][6] + "\n"  # Kopfzeile
      table += "```"  # Ende des Code-Blocks
    print(table)
    if len(table1) != 0:
      table = "```\n"  # Anfang des Code-Blocks
      table += asp(str("# "), 2) + asp("TrainerName", a1) + " " + asp(
          "Win", a2) + " " + asp("Lose", a2) + " " + asp(
              "StatSum", a2) + "\n"  # Kopfzeile
      for i in range(10):
        table += asp(
            str(i + 1), 2) + " " + asp(table1[i + 20][0], a1) + " " + asp(
                str(table1[i + 20][1]),
                a2) + " " + asp(str(table1[i + 20][2]), a2) + " " + asp(
                    str(table1[i + 20][4]), a2 + 3) + " " + asp(
                        str(table1[i + 20][3]),
                        a2 + 2) + "  " + table1[i + 20][6] + "\n"  # Kopfzeile
      table += "```"  # Ende des Code-Blocks
    print(table)
  # postet Spieltagergebnisse sowie kommende Matches
  blockPrint()
  table1 = ""

  l = []
  r = []
  table1 = []
  table2 = []
  spielergen1 = []
  spielergen2 = []
  spielergen3 = []
  pkmgen1 = []
  pastresults11 = []
  pastresults12 = []
  pastresults13 = []
  table1, spielergen1, pastresults11, pastresults12, pastresults13 = spieltag2(
      day + 1)

  rsp1 = []
  rsp21 = []
  rsp22 = []
  rsp23 = []
  rsp21 = rr2(table1[:10], day + 1)
  rsp22 = rr2(table1[10:-10], day + 1)
  rsp23 = rr2(table1[-10:], day + 1)

  for i in range(9):
    table = "```\n"  # Anfang des Code-Blocks
    l.append([])
    table += "Spieltag " + str(i + 1) + "\n"

    for e in range(5):
      if pastresults11[i][e + 1] == 1:
        l[i].append("1|0 ")
      elif pastresults11[i][e + 1] == 0:
        l[i].append("0|1 ")
      else:
        l[i].append("?|? ")
      table += asp(rsp21[i][e][0][6], 40) + " " + asp(
          rsp21[i][e][0][0], 11) + l[i][e] + asp(
              rsp21[i][e][1][0], 11) + " " + asp(rsp21[i][e][1][6], 40) + "\n"
    table += "```"  # Ende des Code-Blocks
    print(table)
  for i in range(9):
    table = "```\n"  # Anfang des Code-Blocks
    l.append([])
    table += "Spieltag " + str(i + 10) + "\n"

    for e in range(5):
      if pastresults11[i + 9][e + 1] == 1:
        l[i + 9].append("1|0 ")
      elif pastresults11[i + 9][e + 1] == 0:
        l[i + 9].append("0|1 ")
      else:
        l[i + 9].append("?|? ")
      table += asp(rsp21[i][e][0][6], 40) + " " + asp(
          rsp21[i][e][0][0], 11) + l[i + 9][e] + asp(
              rsp21[i][e][1][0], 11) + " " + asp(rsp21[i][e][1][6], 40) + "\n"
    table += "```"  # Ende des Code-Blocks
    print(table)
  l = []
  for i in range(9):
    table = "```\n"  # Anfang des Code-Blocks
    l.append([])
    table += "Spieltag " + str(i + 1) + "\n"

    for e in range(5):
      if pastresults12[i][e + 1] == 1:
        l[i].append("1|0 ")
      elif pastresults12[i][e + 1] == 0:
        l[i].append("0|1 ")
      else:
        l[i].append("?|? ")
      table += asp(rsp22[i][e][0][6], 40) + " " + asp(
          rsp22[i][e][0][0], 11) + l[i][e] + asp(
              rsp22[i][e][1][0], 11) + " " + asp(rsp22[i][e][1][6], 40) + "\n"
    table += "```"  # Ende des Code-Blocks
    print(table)
  for i in range(9):
    table = "```\n"  # Anfang des Code-Blocks
    l.append([])
    table += "Spieltag " + str(i + 10) + "\n"

    for e in range(5):
      if pastresults12[i + 9][e + 1] == 1:
        l[i + 9].append("1|0 ")
      elif pastresults12[i + 9][e + 1] == 0:
        l[i + 9].append("0|1 ")
      else:
        l[i + 9].append("?|? ")
      table += asp(rsp22[i][e][0][6], 40) + " " + asp(
          rsp22[i][e][0][0], 11) + l[i + 9][e] + asp(
              rsp22[i][e][1][0], 11) + " " + asp(rsp22[i][e][1][6], 40) + "\n"
    table += "```"  # Ende des Code-Blocks
    print(table)
  l = []
  for i in range(9):
    table = "```\n"  # Anfang des Code-Blocks
    l.append([])
    table += "Spieltag " + str(i + 1) + "\n"

    for e in range(5):
      if pastresults13[i][e + 1] == 1:
        l[i].append("1|0 ")
      elif pastresults13[i][e + 1] == 0:
        l[i].append("0|1 ")
      else:
        l[i].append("?|? ")
      table += asp(rsp23[i][e][0][6], 40) + " " + asp(
          rsp23[i][e][0][0], 11) + l[i][e] + asp(
              rsp23[i][e][1][0], 11) + " " + asp(rsp23[i][e][1][6], 40) + "\n"
    table += "```"  # Ende des Code-Blocks
    print(table)
  for i in range(9):
    table = "```\n"  # Anfang des Code-Blocks
    l.append([])
    table += "Spieltag " + str(i + 10) + "\n"

    for e in range(5):
      if pastresults13[i + 9][e + 1] == 1:
        l[i + 9].append("1|0 ")
      elif pastresults13[i + 9][e + 1] == 0:
        l[i + 9].append("0|1 ")
      else:
        l[i + 9].append("?|? ")
      table += asp(rsp23[i][e][0][6], 40) + " " + asp(
          rsp23[i][e][0][0], 11) + l[i + 9][e] + asp(
              rsp23[i][e][1][0], 11) + " " + asp(rsp23[i][e][1][6], 40) + "\n"
    table += "```"  # Ende des Code-Blocks
    print(table)
  enablePrint()
  incday()
  print("done")

def gameday2():

  day = 0
  day = int(getday())
  print(day)
  a1 = 12
  a2 = 4
  f = 20
  f2 = 8
  f3 = 16
  table1 = []
  table2 = []
  table3 = []
  spielergen1 = []
  spielergen2 = []
  spielergen3 = []
  pkmgen1 = []
  pkmgen2 = []
  pkmgen3 = []
  pastresults11 = []
  pastresults12 = []
  pastresults13 = []
  pastresults21 = []
  pastresults22 = []
  pastresults31 = []
  pastresults32 = []
  pastresults33 = []
  table1, spielergen1, pastresults11, pastresults12, pastresults13 = spieltag2(
      day + 1)
  print(table1)
  table1 = sorted(table1, key=sortierfunktion)


  if len(table1) != 0:
    table = "```\n"  # Anfang des Code-Blocks
    if day + 1 in [7, 8, 9, 10, 17, 18, 19, 20, 27, 28, 29, 30]:
      if day + 1 in [7, 17, 27]:
        table += "TRANSFERTAG: " + str(1) + " von 4\n"
      elif day + 1 in [8, 18, 28]:
        table += "TRANSFERTAG: " + str(2) + " von 4\n"
      elif day + 1 in [9, 19, 29]:
        table += "TRANSFERTAG: " + str(3) + " von 4\n"
      elif day + 1 in [10, 20, 20]:
        table += "TRANSFERTAG: " + str(4) + " von 4\n"

    table += asp(str("# "), 2) + asp("TrainerName", a1) + " " + asp(
        "Win", a2) + " " + asp("Lose", a2) + " " + asp(
            "StatSum", a2) + " Totaldmg " + "\n"  # Kopfzeile
    for i in range(10):
      table += asp(str(i + 1), 2) + " " + asp(table1[i][0], a1) + " " + asp(
          str(table1[i][1]), a2) + " " + asp(str(
              table1[i][2]), a2) + " " + asp(
                  str(table1[i][4]), a2 + 3) + " " + asp(
                      str(table1[i][3]),
                      a2 + 2) + "  " + table1[i][6] + "\n"  # Kopfzeile
    table += "```"  # Ende des Code-Blocks
    print(table)
    if len(table1) != 0:
      table = "```\n"  # Anfang des Code-Blocks
      table += asp(str("# "), 2) + asp("TrainerName", a1) + " " + asp(
          "Win", a2) + " " + asp("Lose", a2) + " " + asp(
              "StatSum", a2) + "\n"  # Kopfzeile
      for i in range(10):
        table += asp(
            str(i + 1), 2) + " " + asp(table1[i + 10][0], a1) + " " + asp(
                str(table1[i + 10][1]),
                a2) + " " + asp(str(table1[i + 10][2]), a2) + " " + asp(
                    str(table1[i + 10][4]), a2 + 3) + " " + asp(
                        str(table1[i + 10][3]),
                        a2 + 2) + "  " + table1[i + 10][6] + "\n"  # Kopfzeile
      table += "```"  # Ende des Code-Blocks
    print(table)
    if len(table1) != 0:
      table = "```\n"  # Anfang des Code-Blocks
      table += asp(str("# "), 2) + asp("TrainerName", a1) + " " + asp(
          "Win", a2) + " " + asp("Lose", a2) + " " + asp(
              "StatSum", a2) + "\n"  # Kopfzeile
      for i in range(10):
        table += asp(
            str(i + 1), 2) + " " + asp(table1[i + 20][0], a1) + " " + asp(
                str(table1[i + 20][1]),
                a2) + " " + asp(str(table1[i + 20][2]), a2) + " " + asp(
                    str(table1[i + 20][4]), a2 + 3) + " " + asp(
                        str(table1[i + 20][3]),
                        a2 + 2) + "  " + table1[i + 20][6] + "\n"  # Kopfzeile
      table += "```"  # Ende des Code-Blocks
    print(table)
  # postet Spieltagergebnisse sowie kommende Matches
  blockPrint()
  table1 = ""

  l = []
  r = []
  table1 = []
  table2 = []
  spielergen1 = []
  spielergen2 = []
  spielergen3 = []
  pkmgen1 = []
  pastresults11 = []
  pastresults12 = []
  pastresults13 = []
  table1, spielergen1, pastresults11, pastresults12, pastresults13 = spieltag2(
      day + 1)

  rsp1 = []
  rsp21 = []
  rsp22 = []
  rsp23 = []
  rsp21 = rr2(table1[:10], day + 1)
  rsp22 = rr2(table1[10:-10], day + 1)
  rsp23 = rr2(table1[-10:], day + 1)

  for i in range(9):
    table = "```\n"  # Anfang des Code-Blocks
    l.append([])
    table += "Spieltag " + str(i + 1) + "\n"

    for e in range(5):
      if pastresults11[i][e + 1] == 1:
        l[i].append("1|0 ")
      elif pastresults11[i][e + 1] == 0:
        l[i].append("0|1 ")
      else:
        l[i].append("?|? ")
      table += asp(rsp21[i][e][0][6], 40) + " " + asp(
          rsp21[i][e][0][0], 11) + l[i][e] + asp(
              rsp21[i][e][1][0], 11) + " " + asp(rsp21[i][e][1][6], 40) + "\n"
    table += "```"  # Ende des Code-Blocks
    print(table)
  for i in range(9):
    table = "```\n"  # Anfang des Code-Blocks
    l.append([])
    table += "Spieltag " + str(i + 10) + "\n"

    for e in range(5):
      if pastresults11[i + 9][e + 1] == 1:
        l[i + 9].append("1|0 ")
      elif pastresults11[i + 9][e + 1] == 0:
        l[i + 9].append("0|1 ")
      else:
        l[i + 9].append("?|? ")
      table += asp(rsp21[i][e][0][6], 40) + " " + asp(
          rsp21[i][e][0][0], 11) + l[i + 9][e] + asp(
              rsp21[i][e][1][0], 11) + " " + asp(rsp21[i][e][1][6], 40) + "\n"
    table += "```"  # Ende des Code-Blocks
    print(table)
  l = []
  for i in range(9):
    table = "```\n"  # Anfang des Code-Blocks
    l.append([])
    table += "Spieltag " + str(i + 1) + "\n"

    for e in range(5):
      if pastresults12[i][e + 1] == 1:
        l[i].append("1|0 ")
      elif pastresults12[i][e + 1] == 0:
        l[i].append("0|1 ")
      else:
        l[i].append("?|? ")
      table += asp(rsp22[i][e][0][6], 40) + " " + asp(
          rsp22[i][e][0][0], 11) + l[i][e] + asp(
              rsp22[i][e][1][0], 11) + " " + asp(rsp22[i][e][1][6], 40) + "\n"
    table += "```"  # Ende des Code-Blocks
    print(table)
  for i in range(9):
    table = "```\n"  # Anfang des Code-Blocks
    l.append([])
    table += "Spieltag " + str(i + 10) + "\n"

    for e in range(5):
      if pastresults12[i + 9][e + 1] == 1:
        l[i + 9].append("1|0 ")
      elif pastresults12[i + 9][e + 1] == 0:
        l[i + 9].append("0|1 ")
      else:
        l[i + 9].append("?|? ")
      table += asp(rsp22[i][e][0][6], 40) + " " + asp(
          rsp22[i][e][0][0], 11) + l[i + 9][e] + asp(
              rsp22[i][e][1][0], 11) + " " + asp(rsp22[i][e][1][6], 40) + "\n"
    table += "```"  # Ende des Code-Blocks
    print(table)
  l = []
  for i in range(9):
    table = "```\n"  # Anfang des Code-Blocks
    l.append([])
    table += "Spieltag " + str(i + 1) + "\n"

    for e in range(5):
      if pastresults13[i][e + 1] == 1:
        l[i].append("1|0 ")
      elif pastresults13[i][e + 1] == 0:
        l[i].append("0|1 ")
      else:
        l[i].append("?|? ")
      table += asp(rsp23[i][e][0][6], 40) + " " + asp(
          rsp23[i][e][0][0], 11) + l[i][e] + asp(
              rsp23[i][e][1][0], 11) + " " + asp(rsp23[i][e][1][6], 40) + "\n"
    table += "```"  # Ende des Code-Blocks
    print(table)
  for i in range(9):
    table = "```\n"  # Anfang des Code-Blocks
    l.append([])
    table += "Spieltag " + str(i + 10) + "\n"

    for e in range(5):
      if pastresults13[i + 9][e + 1] == 1:
        l[i + 9].append("1|0 ")
      elif pastresults13[i + 9][e + 1] == 0:
        l[i + 9].append("0|1 ")
      else:
        l[i + 9].append("?|? ")
      table += asp(rsp23[i][e][0][6], 40) + " " + asp(
          rsp23[i][e][0][0], 11) + l[i + 9][e] + asp(
              rsp23[i][e][1][0], 11) + " " + asp(rsp23[i][e][1][6], 40) + "\n"
    table += "```"  # Ende des Code-Blocks
    print(table)
  enablePrint()
  print("done")



#gameday2()

#resetseason()
start_Game()
#change1("get MISDREAVUS move3 RETURN")
#change1("scout GOREBYSS give CLEFABLE")