class BattleTeam:
  def __init__(self, name,pokemon, moveset):
      self.name = name
      self.pokemon = pokemon
      self.moveset = moveset

