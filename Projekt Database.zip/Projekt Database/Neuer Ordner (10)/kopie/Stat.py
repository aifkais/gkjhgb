

class Stat:
  def __init__(self,pokename,type1,type2,hp,attack,defense,spattack,spdefense,speed,strat,m1,m2,m3,m4):
    self.pokename = pokename
    self.type1 = type1
    self.type2 = type2
    self.hp = hp
    self.attack = attack
    self.defense = defense
    self.spattack = spattack
    self.spdefense = spdefense
    self.speed = speed
    self.strat= strat
    self.m1 = m1
    self.m2 = m2
    self.m3 = m3
    self.m4 = m4
    
  

