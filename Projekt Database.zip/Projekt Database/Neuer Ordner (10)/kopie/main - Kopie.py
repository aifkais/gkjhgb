import discord
import os
from discord.ext import commands
from Fight import getData, linetoArr
from KaderTemplate import showTemplate
from Game_Init import gameinit
from Game_Init import initTrainer
from Game_Init import initPokemontoTrainer

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix='!', intents=intents)
last_message = None


@bot.event
async def on_ready():
    print(f'Logged in as {bot.user.name}')

@bot.event
async def on_message(msg):
    if msg.author == bot.user:
        return
    if msg.content.startswith('0'):  # Show content
        print('[New message]', msg.content)
        await msg.delete()
        global last_message
        if last_message:
            await last_message.edit(content=KaderTemplate())
        else:
            last_message = await msg.channel.send(showTemplate())

    if msg.author.id == 347156882374262795 and  msg.content.startswith('1'):
      #gameinit()
      #initPokemontoTrainer()
      getData("tamer","crushgirl",1)
      
DISCORD_TOKEN = os.environ['DISCORD_TOKEN']

bot.run(DISCORD_TOKEN)
