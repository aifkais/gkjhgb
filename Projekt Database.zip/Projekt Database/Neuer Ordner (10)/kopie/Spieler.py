class Spieler:
  def __init__(self,gen, id, trainername, pokemon,geld, win10,gamesplayed, winrate,win,lose, stärke, punkte):
    self.gen =gen  
    self.id = id
    self.trainername = trainername
    self.pokemon = pokemon
    self.geld = geld
    self.win10 = win10
    self.gamesplayed = gamesplayed
    self.winrate = winrate
    self.win = win
    self.lose = lose
    self.stärke = stärke
    self.punkte = punkte
