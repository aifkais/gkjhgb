
import sys, os

from BattleTeam import BattleTeam
import sqlite3
from Game_Init import tupel_to_string
from Game_Init import tupel_to_string2
from Move import Move
from Stat import Stat
from PokeLib3 import moveList3
from PokeLib2 import moveList2
from PokeLib1 import moveList1
import random
import math

cattack = False
cchange = False
confu = False
par = False
miss = False
death = False
r = 0


chosenmove1 = []
chosenmove2 = []
attackmove1 = []
attackmove2 = []
pokemon = []
team1moves = []
team2moves = []
moveset1 = []
moveset2 = []
pokestat1 = [False, False, False, False, False, False, False, False, False, False, False, False, False]
pokestat2 = [False, False, False, False, False, False, False, False, False, False, False, False, False]
sun=0       #par slp gif brn frz ko cnf fln lch lov crs hyp
rain = 0
sandstorm = 0
hail = 0
miss = [False, False]
lose1 = False
lose2 = False
flag1 = 0
flag2 = 0
slp1 = 0
slp2 = 0
hyp1 = 0
hyp2 = 0

primemove1 = []
primemove2 = []


pokeval1 = [0,0,0,0,0,0,0,0]
pokeval2 = [0,0,0,0,0,0,0,0]
#atk def spatk spdef init eva acc crt 
attackmove = []
healthbar1=[]
healthbar2=[]
defeat = False
stats1 = [] 
stats2 = []
stattemplate = ["Type1","Type2","HP", "Attack", "Defense", "Sp.Attack", "Sp.Defense", "Speed","Strat"]
onelose = False

def onematch(turniername,trainer1, gen1,trainer2,gen2):
  #blockPrint()
  getData(trainer1,gen1,trainer2,gen2)
  return fightmatch(trainer1,trainer2,turniername,gen1,gen2)

def getData(trainer1,gen1, trainer2, gen2):
  global defeat
  global stats1
  global stats2
  global team1moves
  global team2moves
  global primemove1
  global primemove2
  pokenames1 = []
  pokenames2 = []
  pokenames1 = kadertoArr(gen1, trainer1, pokenames1)
  pokenames2 = kadertoArr(gen2, trainer2, pokenames2)

  stats1 = makestats(pokenames1, gen1,stats1)
  stats2 = makestats(pokenames2, gen2,stats2)
  team1moves = makemoves(stats1, team1moves)
  team2moves = makemoves(stats2, team2moves)
  primemove1 = makemoves(stats1, primemove1)
  primemove2 = makemoves(stats2, primemove2)



def fightmatch(trainer1,trainer2,turniername,gen1,gen2): # Trainer Name 1 und 2 und Genzahl
  p1first = False
  dmg1 = 0
  dmg2 = 0
  global chosenmove1 #List 
  global chosenmove2 # List
  global healthbar1 # List of Integers <--
  global healthbar2 
  global stats1 # List of Pokestats + Movenames  <--
  global stats2 
  global team1moves # List of Movesets <--?
  global team2moves
  global attackmove1 # List of Moves in Movesets
  global attackmove2
  global pokestat1 # List of Booleans like par, slp, gif, brn, frz, ko, cnf, fln, lov, crs <--
  global pokestat2
  global pokeval1 # List of Integers like atk, def, spatk, spdef, init, eva, acc, crt
  global pokeval2
  global lose1 # Sind alle HP = 0?
  global lose2
  global r # Rundenzahl
  global flag1 
  global flag2 
  global primemove1
  global primemove2
  global hyp1
  global hyp2
  global slp1
  global slp2


  print(turniername +" Battle!") #Liga1 Battle
  print(trainer1 + " gegen " + trainer2) #tamer gegen lass
  print()
  print("Team "+ trainer1 + ":")
  for i in range(4):
    print(stats1[i].pokename)
  print()
  print("Team "+ trainer2+ ":")
  for i in range(4):
    print(stats2[i].pokename)
  print()
  for i in range(4):# HP initialisieren
    healthbar1.append(initHP(stats1[i].hp))
    healthbar2.append(initHP(stats2[i].hp))

  a = False
  print(stats1[0].pokename + " mit " + str(healthbar1[0]) +" HP") #Pikachu mit 100 HP
  print(stats2[0].pokename+ " mit " + str(healthbar2[0]) +" HP\n")
  while lose1 != True or lose2 != True: # Scheife solange es noch Pokemon gibt

    

    while healthbar1[0] > 0 or healthbar2[0] >0:
      attackmove1=getmove(team1moves, stats1,stats2,pokeval1,pokeval2,flag1,healthbar1[0],pokestat2,primemove1)  # players chose move according to AI
      attackmove2=getmove(team2moves, stats2,stats1,pokeval1,pokeval2,flag2,healthbar2[0],pokestat1,primemove2) 
      p1first = choseprio(pokestat1[0],pokestat2[0],attackmove1[0][4],attackmove2[0][4],stats1[0].speed,stats2[0].speed, p1first) # chose Prio
      if p1first:
        print(stats1[0].pokename+ " setzt " + attackmove1[0][0] +" ein") # Nebulak setzt DreamEater ein
        dmg1 = fightstep1(stats1[0],stats2[0],pokestat1, pokeval1, pokeval2,attackmove1,healthbar1, healthbar2,slp1,hyp1)
        dmg1 = math.ceil(dmg1*(100-random.randint(0,15))/100)
        print("verursacht " + str(dmg1) + " Schaden\n")
        healthbar2[0] -=dmg1
        aftereffect(attackmove1,attackmove2,stats1,stats2,pokeval1,pokeval2,pokestat1,pokestat2,healthbar1,healthbar2 ,dmg1,1)

        if healthbar2[0] > 0:

          print(stats2[0].pokename+ " setzt " + attackmove2[0][0] +" ein") # Traumato setzt Pfund ein
          dmg2 = fightstep1(stats2[0],stats1[0], pokestat2,pokeval2, pokeval1,attackmove2,healthbar2, healthbar1,slp2,hyp2)
          dmg2 = math.ceil(dmg2*(100-random.randint(0,15))/100)
          print("verursacht " + str(dmg2) + " Schaden\n")
          healthbar1[0] -=dmg2
          aftereffect(attackmove2,attackmove1,stats2,stats1,pokeval2,pokeval1,pokestat2,pokestat1,healthbar2,healthbar1 ,dmg2,2)

        
        afterdamage(healthbar1[0],healthbar2[0],stats1,pokestat1)
        afterdamage(healthbar2[0],healthbar1[0],stats2,pokestat2)
        clearafterdamage()

        if healthbar1[0] <= 0:
            print(stats1[0].pokename+ " ist KO!\n") # Nebulak ist K.O!
            
        if healthbar2[0] <= 0:
            print(stats2[0].pokename+ " ist KO!\n") # Traumato ist K.O!
        break
      elif not p1first:

        print(stats2[0].pokename+ " setzt " + attackmove2[0][0] +" ein") # Traumato setzt Pfund ein
        dmg2 = fightstep1(stats2[0],stats1[0], pokestat2,pokeval2, pokeval1,attackmove2,healthbar2, healthbar1,slp2,hyp2)
        dmg2 = math.ceil(dmg2*(100-random.randint(0,15))/100)
        print("verursacht " + str(dmg2) + " Schaden\n")
        healthbar1[0] -=dmg2
        aftereffect(attackmove2,attackmove1,stats2,stats1,pokeval2,pokeval1,pokestat2,pokestat1,healthbar2,healthbar1 ,dmg2,2)
        if healthbar1[0] > 0:
          print(stats1[0].pokename+ " setzt " + attackmove1[0][0] +" ein") # Nebulak setzt DreamEater ein
          dmg1 = fightstep1(stats1[0],stats2[0],pokestat1, pokeval1, pokeval2,attackmove1,healthbar1, healthbar2,slp1,hyp1)
          dmg1 = math.ceil(dmg1*(100-random.randint(0,15))/100)
          print("verursacht " + str(dmg1) + " Schaden\n")
          healthbar2[0] -=dmg1
          aftereffect(attackmove1,attackmove2,stats1,stats2,pokeval1,pokeval2,pokestat1,pokestat2,healthbar1,healthbar2 ,dmg1,1)
        afterdamage(healthbar1[0],healthbar2[0],stats1,pokestat1)
        afterdamage(healthbar2[0],healthbar1[0],stats2,pokestat2)
        clearafterdamage()
        if healthbar2[0] <= 0:
            print(stats2[0].pokename+ " ist KO!\n") # Traumato ist K.O!

        if healthbar1[0] <= 0:
            print(stats1[0].pokename+ " ist KO!\n") # Nebulak ist K.O!
        break
    #afterdamage(healthbar1[0],healthbar2[0],stats1,pokestat1)
    #afterdamage(healthbar2[0],healthbar1[0],stats2,pokestat2)
    if healthbar1[0] <= 0:
      
      clearpokestat(pokestat1)
      clearpokeval(pokeval1)
      lose1 =changequeue(healthbar1,stats1,team1moves,primemove1,lose1 )
      if not lose1:
        print(stats1[0].pokename + " mit " + str(healthbar1[0]) +" HP") #Pikachu mit 100 HP
        print(stats2[0].pokename+ " mit " + str(healthbar2[0]) +" HP\n")
    if healthbar2[0] <=0:

      clearpokestat(pokestat2)
      clearpokeval(pokeval2)
      lose2 =changequeue(healthbar2,stats2,team2moves,primemove2,lose2 )
      if not lose2:
        print(stats1[0].pokename + " mit " + str(healthbar1[0]) +" HP") #Pikachu mit 100 HP
        print(stats2[0].pokename+ " mit " + str(healthbar2[0]) +" HP\n")
        #afterdamage Hail, Posion
    if lose1 or lose2:
      break

  if lose1 and lose2:
    print("remi keiner hat gewonnen")
    enablePrint()
    resetall()
    fightmatch(trainer1,trainer2,turniername)
  if lose1:
    print(trainer1+" hat keine Pokemon mehr übrig..")
    enablePrint()
    resetall()
    print(trainer2+" gewinnt gegen "+trainer1) #def getcell(tabelle, x,y,ywert):
    return True
    #wintodb("Trainer"+str(gen1)+"Gen","Lose",getcell("Trainer"+str(gen1)+"Gen","Lose","TrainerName",trainer1)+1,"TrainerName",trainer1)
    #wintodb("Trainer"+str(gen2)+"Gen","Win",getcell("Trainer"+str(gen2)+"Gen","Win","TrainerName",trainer2)+1,"TrainerName",trainer2)
  if lose2:
    print(trainer2+" hat keine Pokemon mehr übrig..")
    enablePrint()
    resetall()
    print(trainer1+ " gewinnt gegen " + trainer2)
    return False
    #wintodb("Trainer"+str(gen1)+"Gen","Win",getcell("Trainer"+str(gen1)+"Gen","Win","TrainerName",trainer1)+1,"TrainerName",trainer1)
    #wintodb("Trainer"+str(gen2)+"Gen","Lose",getcell("Trainer"+str(gen2)+"Gen","Lose","TrainerName",trainer2)+1,"TrainerName",trainer2)
  resetall()

def resetall():

  global chosenmove1 #List 
  global chosenmove2 # List
  global healthbar1 # List of Integers <--
  global healthbar2 
  global stats1 # List of Pokestats + Movenames  <--
  global stats2 
  global team1moves # List of Movesets <--?
  global team2moves
  global attackmove1 # List of Moves in Movesets
  global attackmove2
  global pokestat1 # List of Booleans like par, slp, gif, brn, frz, ko, cnf, fln, lov, crs <--
  global pokestat2
  global pokeval1 # List of Integers like atk, def, spatk, spdef, init, eva, acc, crt
  global pokeval2
  global lose1 # Sind alle HP = 0?
  global lose2
  global r # Rundenzahl
  global flag1 
  global flag2 
  global primemove1
  global primemove2
  global hyp1
  global hyp2
  global slp1
  global slp2

  clear_list(chosenmove1)
  clear_list(chosenmove2)
  clear_list(healthbar1)
  clear_list(healthbar2)
  clear_list(stats1)
  clear_list(stats2)
  clear_list(team1moves)
  clear_list(team2moves)
  clear_list(attackmove1)
  clear_list(attackmove2)
  pokestat1 = [False, False, False, False, False, False, False, False, False, False, False, False, False]
  pokestat2 = [False, False, False, False, False, False, False, False, False, False, False, False, False]
  pokeval1 = [0,0,0,0,0,0,0,0]
  pokeval2 = [0,0,0,0,0,0,0,0]
  lose1 = False
  lose2 = False
  r = 0
  flag1 = 0
  flag2 = 0
  primemove1 = []
  primemove2 = []
  slp1 = 0
  slp2 = 0
  hyp1 = 0
  hyp2 = 0
  
def changequeue(list1,list2,list3,list4,loscon):
  e = 0
  while list1[0]<=0:
      e=e+1
      element = list1.pop(0)
      list1.append(element)
      element = list2.pop(0)
      list2.append(element)
      element = list3.pop(0)
      list3.append(element)
      element = list4.pop(0)
      list4.append(element)
      
      if e >= 4:
        loscon = True
        return loscon
  return loscon
  
  




#par slp gif brn frz ko cnf fln lch lov crs 
def afterdamage(healthbar1,healthbar2,stats1,pokestat1):
  global hail
  global sandstorm
  if pokestat1[2] or pokestat1[3]:
    healthbar1-math.ceil(stats1[0].hp / 8)
    if pokestat1[2]:
      print("Gift fügt " +stats1[0].pokename + " "+ str(math.ceil(stats1[0].hp / 8)) + " zu!")
    
    if pokestat1[3]:
      print("Verbrennung fügt " +stats1[0].pokename + " "+  str(math.ceil(stats1[0].hp / 8)) + " zu!")
  if pokestat1[7]:
    print("Egelsamen fügt " +stats1[0].pokename + " "+  str(math.ceil(stats1[0].hp / 8)) + " zu!")
    healthbar1[0]-math.ceil(stats1[0].hp / 8)
    healthbar2[0]+math.ceil(stats1[0].hp / 8)
    if healthbar2 > stats2[0].hp*2+110:
      healthbar2[0] = stats2[0].hp*2+110
  if pokestat1[8]:
    healthbar1-math.ceil(stats1[0].hp / 4)
    print("Fluch fügt " +stats1[0].pokename + str(math.ceil(stats1[0].hp / 8)) + " zu!")
  if hail >= 1 and stats1[0].type != "Ice":
    healthbar1-math.ceil(stats1[0].hp / 4)
    print("Hagel fügt " +stats1[0].pokename + str(math.ceil(stats1[0].hp / 16)) + " zu!")
  if sandstorm >= 1 and (stats1[0].type !=( "Rock" or"Steel" or "Ground" )):
    healthbar1-math.ceil(stats1[0].hp / 4)
    print("Sandsturm fügt " +stats1[0].pokename + str(math.ceil(stats1[0].hp / 8)) + " zu!")

def clearafterdamage():
  global slp1
  global slp2
  global hyp1
  global hyp2
  clearweather()
  slp1 =clearslp(slp1)
  slp2 =clearslp(slp2)
  hyp1 = clearhyp(hyp1)
  hyp2 = clearhyp(hyp2)

def vtf(pokeval1):
  if pokeval1 == 0:
    return 1
  elif pokeval1 > 0:
    return 1+pokeval1*0.5
  elif pokeval1 == -6:
    return 2/8
  elif pokeval1 == -5:
    return 2/7
  elif pokeval1 == -4:
    return 2/6
  elif pokeval1 == -3:
    return 2/5
  elif pokeval1 == -2:
    return 2/4
  elif pokeval1 == -1:
    return 2/3

def clearpokestat(pokestat1):
    for i in range(len(pokestat1)):
      pokestat1[i] = False
#par slp gif brn frz ko cnf fln lch lov crs 
def softclearpokestat(pokestat1):
    for i in range(5):
      pokestat1[i+5] = False     
def clearpokeval(pokeval1):
    for i in range(len(pokeval1)):
      pokeval1[i] = 1
def clearweather():
    global sun
    global hail
    global sandstorm
    global rain
    if sun == hail ==sandstorm == rain == 0:
        return
    if sun >0:
        sun -=1
    if hail >0:
        hail -=1
    if sandstorm >0:
        sandstorm -=1
    if rain >0:
        rain -=1
def clearslp(slp1):
  if slp1==0:
    return slp1
  else:
    slp1 -=1
    return slp1
def clearhyp(hyp1):
  if hyp1==0:
    return hyp1
  else:
    hyp1 -=1
    return hyp1


def clear_list(my_list):
    my_list.clear()
  

def initHP(hp):
  return 2*hp+110
  
def truevalue(stat):
  return 2*stat+5
  
def fightstep1(stats1, stats2,pstatus1,pokeval1,pokeval2,attackmove1,healthbar1, healthbar2,slp1,hyp1):
  global miss
  global sun
  global hail
  global sandstorm
  global rain
  
  phy = ["Normal","Fighting","Flying","Poison","Ground","Rock","Bug","Ghost","Steel"]
  stab = 1
  effective = 1
  sundmg = 1
  sunnerf = 1
  rainnerf = 1
  raindmg = 1
  burndmg = 1
  miss = False
  if slp1!=0: #Sleep,Flinch, Freeze, ko
    print(stats1.pokename+" schläft friedlich")
    return 0
  if pstatus1[4]: #Sleep,Flinch, Freeze, ko
    print(stats1.pokename+" schreckt zurück")
    return 0
  if pstatus1[5]: #Sleep,Flinch, Freeze, ko
    print(stats1.pokename+" ist in Eis erstarrt")
    return 0
  if hyp1!=0: #Sleep,Flinch, Freeze, ko
    print(stats1.pokename+" muss sich aufladen")
    return 0
  if pstatus1[11]: #Sleep,Flinch, Freeze, ko
    return 0
  if pstatus1[6] and random.random()<0.5: #Confuse 50% + selfdamage
    print(stats1.pokename+" ist verwirrt")
    if random.random()<0.5:
      print(stats1.pokename+" hat sich selbst verletzt")
      healthbar2[0] =-tD(40,"Normal", stats1, stats2, pokeval1, pokeval2)
      return 0
  if pstatus1[0] and random.random()<0.75: #Paralyse 75% Trefferrate
    print(stats1.pokename+" ist paralysiert")
    return 0
  if pstatus1[9] and random.random()<0.5: #love 50%
    print(stats1.pokename+" ist starr vor Liebe")
    return 0
  if attackmove1[0][3] != 0:
    if random.random()*100>= vtf(pokeval1[7]) * attackmove1[0][3]: #Miss
      print("Der Angriff ging daneben")
      return 0

  effective = iseffective(attackmove1[0][1], stats2.type1,stats2.type2) #Wie effektiv?


  if effective==0:
    print("Der Angriff hat keine Wirkung")
    return 0
  miss = True
  if pstatus1[3] and stats1.type1 in phy: #burn reduces physical attacks
    burndmg = 0.75
  if attackmove1[0][1] == (stats1.type1 or stats1.type2): # stab does 1,5 damage
    stab = 1.50
  if sun != 0:
    if attackmove1[0][1] == "Fire": #fireboost by sunshine
        sundmg = 1.5
    elif attackmove1[0][1] == "Water":#Waternerf by sunshine
        sunnerf = 0.5
  if rain != 0:
    if attackmove1[0][1] == "Fire":#Waterboost by rain
        raindmg = 1.5
    elif attackmove1[0][1] == "Water":#Firenerf by rain
        rainnerf = 0.5
  if random.random()<0.0625*pokeval1[7]: #Crit
    print("Volltreffer!")
    if effective >= 2:
      print("Der Angriff ist sehr Effektiv")
    return (tD2(attackmove1[0][2],attackmove1[0][1], stats1, stats2, pokeval1, pokeval2)*effective*stab*2*sundmg*raindmg)
  if effective >= 2:
    print("Der Angriff ist sehr Effektiv")
  return (tD(attackmove1[0][2],attackmove1[0][1], stats1, stats2, pokeval1, pokeval2)*effective*stab*burndmg*sundmg*raindmg*sunnerf*rainnerf)
  
#par slp gif brn frz ko cnf fln lch lov crs 

def wintodb(Tabelle,x,xwert, y,ywert):
  conn = sqlite3.connect('PokeData.db')
  cursor = conn.cursor()
  cursor.execute("UPDATE " + Tabelle + " SET "+ x +" = \""+str(xwert)+"\" WHERE "+y +"=\""+str(ywert)+"\"")

  conn.commit()
  conn.close()

def delcell(Tabelle,x, y,ywert):
  conn = sqlite3.connect('PokeData.db')
  cursor = conn.cursor()
  cursor.execute("DELETE FROM " + Tabelle + " SET "+ x +" = NULL WHERE "+y +"=\""+ywert+"\"")

  conn.commit()
  conn.close()

def tD2(pw,type,stats1,stats2, pokeval1, pokeval2):
  phy = ["Normal","Fighting","Flying","Poison","Ground","Rock","Bug","Ghost","Steel"]
  spec  =["Fire","Water","Grass","Electric","Psychic","Ice","Dragon","Dark"]
  zwei = 2
  if pw == 0:
    zwei = 0
  if pokeval1[0] <1:
    pokeval1[0]=1
  if pokeval1[2]<1:
    pokeval1[2]=1
  if pokeval2[1]> 1:
    pokeval2[1]= 1
  if pokeval2[3] > 1:
    pokeval2[3]= 1

  if type in phy:
    return math.ceil(math.ceil(42*stats1.attack*vtf(pokeval1[0])/stats2.defense*vtf(pokeval2[1])*pw)/50)+zwei
  elif type in spec:
    return math.ceil(math.ceil(42*stats1.spattack*vtf(pokeval1[2])/stats2.spdefense*vtf(pokeval2[3])*pw)/50)+zwei
  return 0


#atk, def, spatk, spdef, init, eva, acc, crt
def tD(pw,type,stats1,stats2, pokeval1, pokeval2):
  phy = ["Normal","Fighting","Flying","Poison","Ground","Rock","Bug","Ghost","Steel"]
  spec  =["Fire","Water","Grass","Electric","Psychic","Ice","Dragon","Dark"]
  zwei = 2
  if pw == 0:
    zwei = 0
  if type in phy:
    return math.ceil(math.ceil(42*stats1.attack*vtf(pokeval1[0])/stats2.defense*vtf(pokeval2[1])*pw)/50)+zwei
  elif type in spec:
    return math.ceil(math.ceil(42*stats1.spattack*vtf(pokeval1[2])/stats2.spdefense*vtf(pokeval2[3])*pw)/50)+zwei
  return 0



def hitormiss(pstatus1,eva2,acc1,pmove1):
  if pstatus1[0] and random.random()<0.75:
      return
  if pstatus1[1] and pstatus1[5]:
    return
  
  


def choseprio(par1,par2,prio1, prio2, spd1,spd2,p1first):
  prio1 = int(prio1)
  prio2 = int(prio2)
  if prio1>prio2:
    p1first = True
    return p1first
  if prio1 <prio2:
    p1first = False
    return p1first
  if par1:
    spd1 = math.ceil(spd1/0.25)
  if par2:
    spd2 = math.ceil(spd2/0.25)
  if spd1 > spd2:
    p1first = True
  elif spd1 < spd2:
    p1first = False
  else:
    p1first = random.choice([True, False])
  return p1first


def boi():
  for e in range(4):
    print(stats1[e].pokename)
    for i in range(4):
      print(team1moves[e][i][0]+"| ", end="")
    print()
  print()
  for e in range(4):
    print(stats2[e].pokename)
    for i in range(4):
      print(team2moves[e][i][0]+"| ", end="")


def iseffective(movetype, type1, type2):
  faktor = 1
  x = ""
  y = ""
  type={
"Normal":0,"Fighting":1,"Flying":2,"Poison":3,"Ground":4,"Rock":5,"Bug":6,"Ghost":7,"Steel":8,"Fire":9,"Water":10,"Grass":11,"Electric":12,"Psychic":13,"Ice":14,"Dragon":15,"Dark":16,"":17
         }
  matrix=[
  [1,1,1,1,1,0.5,1,0,0.5,1,1,1,1,1,1,1,1],
  [2,1,0.5,0.5,1,2,0.5,0,2,1,1,1,1,0.5,2,1,2],
  [1,2,1,1,1,0.5,2,1,0.5,1,1,2,0.5,1,1,1,1],
  [1,1,1,0.5,0.5,0.5,1,0.5,0,1,1,2,1,1,1,1,1],
  [1,1,0,2,1,2,0.5,1,2,2,1,0.5,2,1,1,1,1],
  [1,0.5,2,1,0.5,1,2,1,0.5,2,1,1,1,1,2,1,1],
  [1,0.5,0.5,0.5,1,1,1,0.5,0.5,0.5,1,2,1,2,1,1,2],
  [0,1,1,1,1,1,1,2,1,1,1,1,1,2,1,1,0.5],
  [1,1,1,1,1,2,1,1,0.5,0.5,0.5,1,0.5,1,2,1,1],
  [1,1,1,1,1,0.5,2,1,2,0.5,0.5,2,1,1,2,0.5,1],
  [1,1,1,1,2,2,1,1,1,2,0.5,0.5,1,1,1,0.5,1],
  [1,1,0.5,0.5,2,2,0.5,1,0.5,0.5,2,0.5,1,1,1,0.5,1],
  [1,1,2,1,0,1,1,1,1,1,2,0.5,0.5,1,1,0.5,1],
  [1,2,1,2,1,1,1,1,0.5,1,1,1,1,0.5,1,1,0],
  [1,1,2,1,2,1,1,1,0.5,0.5,0.5,2,1,1,0.5,2,1],
  [1,1,1,1,1,1,1,1,0.5,1,1,1,1,1,1,2,1],
  [1,0.5,1,1,1,1,1,2,1,1,1,1,1,2,1,1,0.5]
  ] 
  x = type[movetype]
  y = type[type1]
  faktor *= matrix[x][y]
  
  if type2 != "":
     y = type[type2]
     faktor *= matrix[x][y]
  return faktor


def getmove(teammoves,stats1,stats2,pokeval1,pokeval2,flag,healthbar,pokestat2,primemoves): #Hier werden die Strategien-Algorythmen ausgeführt
  
  
  chosenmove=[]
  chosenmove = teammoves

  dmg=[]
  if stats1[0].strat == 1: #Standartstrat AI sucht sich den Angriff mit der höchsten Dmg (verbesserungswürdig, weil Wetterfaktoren noch keine Rolle spielt)
    mostdamage(teammoves,stats1,stats2,pokeval1,pokeval2,chosenmove,flag,dmg)
  if stats1[0].strat == 2:  #Lässt Himeko-Chan mit ihrer jahrelanger Leidenschaft und fundiertem Fachwissen als PokeExpertin entscheiden! -> 
    randarr(chosenmove[0])

  if stats1[0].strat == 3: # oberster Angriff in Liste wird immer zuerst ausgeführt -> Annoyer, Booster, Evation, Spiker, Weather User
    if flag == 0:
      flag = flag +1
      chosenmove[0]= primemoves[0]
    else:
      mostdamage(teammoves,stats1,stats2,pokeval1,pokeval2,chosenmove,flag,dmg)
  if stats1[0].strat ==4:  # oberster Angriff in Liste wird immer 2mal zuerst ausgeführt -> Booster, Evation, Spiker
    if flag > 2:
      flag = flag +1
      chosenmove[0]= primemoves[0]

    else:
      mostdamage(teammoves,stats1,stats2,pokeval1,pokeval2,chosenmove,flag,dmg)
  if stats1[0].strat ==5: # Wenn das Pokemon low ist, wird es stets den ersten Angriff wählen -> Boomer, Healer
    if healthbar[0] >= (stats1[0].hp*2+110)/50:
      chosenmove[0]= primemoves[0]

    else:
      mostdamage(teammoves,stats1,stats2,pokeval1,pokeval2,chosenmove,flag,dmg)
       #par slp gif brn frz ko cnf fln lch lov crs 
  if stats1[0].strat == 6:
    if check_booleans(pokestat2,1): # Wenn der Gegner noch keine Statusveränderungen hat, dann wird das pokemon seinen ersten Angriff machen
      chosenmove[0]= primemoves[0]
    else:
      mostdamage(teammoves,stats1,stats2,pokeval1,pokeval2,chosenmove,flag,dmg)
  if stats1[0].strat == 7:     
    if check_booleans(pokestat2,1): # Wenn der Gegner noch keine Statusveränderungen hat, dann wird das pokemon seinen ersten Angriff machen
                                    #Wenn er nur einen hat, wird der 2 angriff ausgewählt
      chosenmove[0]= primemoves[0]
      if check_booleans(pokestat2,2):
        chosenmove[0]= primemoves[0]

        chosenmove[0].insert(0, chosenmove[0].pop(1))
    else:
      mostdamage(teammoves,stats1,stats2,pokeval1,pokeval2,chosenmove,flag,dmg)
  return chosenmove[0]

def check_booleans(lst,zahl):
    count_true = 0
    for item in lst:
        if item:
            count_true += 1
            if count_true >= zahl:
                return True
    return False

def randarr(liste):
  zz = random.randint(0,3)
  liste.insert(0,liste.pop(zz))
  return liste



def mostdamage(teammoves,stats1,stats2,pokeval1,pokeval2,chosenmove,flag,dmg):
    for i in range(len(teammoves)):
      dmg.append(math.ceil(iseffective(chosenmove[0][i][1],stats2[0].type1,stats2[0].type2)*tD(chosenmove[0][i][2],chosenmove[0][i][1], stats1[0],stats2[0],pokeval1,pokeval2)))

    for i in range(4):
      chosenmove[0][i].append(dmg[i])
    chosenmove[0] = sorted(chosenmove[0], key=lambda x: (x[-1], random.random()), reverse=True)

def custom_sort(lst):
  last_element = lst[-1]
  return (last_element, random.random())



def tupel_to_integer(tupel):
  return int(''.join(str(e) for e in tupel))


def makemoves(stats,  teammoves):

  for i in range(len(stats)):
    print(stats[i].pokename)
    print(stats[i].m1)
    print(stats[i].m2)
    print(stats[i].m3)
    print(stats[i].m4)
    
    teammoves.append([])
    if len(stats[i].m1) != 0:
      teammoves[i].append(Move("","",0,0,0,0,0,0))
      teammoves[i][0]=movetoArr(stats[i].m1, teammoves[i])
    if len(stats1[i].m2) != 0:
      teammoves[i].append(Move("","",0,0,0,0,0,0))
      teammoves[i][1]=movetoArr(stats[i].m2, teammoves[i])
    if len(stats1[i].m3) != 0:
      teammoves[i].append(Move("","",0,0,0,0,0,0))
      teammoves[i][2]=movetoArr(stats[i].m3, teammoves[i])
    if len(stats1[i].m4) != 0:
      teammoves[i].append(Move("","",0,0,0,0,0,0))
      teammoves[i][3]=movetoArr(stats[i].m4, teammoves[i])
  return teammoves


def makestats(pokenames, gen,statslist):  
  tempstat = []
  tempmove = ["","","",""]
  for i in range(len(pokenames)):
    statslist.append(Stat(pokenames[i],"","", 0, 0, 0, 0, 0, 0 , 0, "","","","")) #ich arbeite niewieder mit Konstruktoren. SOOO USELESS!!!
    tempstat=linetoArr("PokeStats"+str(gen),"Species",pokenames[i], tempstat)#profile = linetoArr("Spieler", "NutzerID",str(id),profile)
    statslist[i].hp = tempstat[0][5]
    statslist[i].type1 = tempstat[0][2]
    statslist[i].type2 = tempstat[0][3]
    statslist[i].attack = tempstat[0][6]
    statslist[i].defense = tempstat[0][7]
    statslist[i].spattack = tempstat[0][8]
    statslist[i].spdefense = tempstat[0][9]
    statslist[i].speed = tempstat[0][10]
    statslist[i].strat = tempstat[0][12]
    statslist[i].m1 = tempstat[0][18]
    statslist[i].m2 = tempstat[0][19]
    statslist[i].m3 = tempstat[0][20]
    statslist[i].m4 = tempstat[0][21]


  return statslist

def stattoArr(genzahl, pokemon, statsList):
  tablename = "PokeStats" + str(genzahl)
  statsList = celltoArr3(tablename, pokemon, statsList)
  return statsList


def kadertoArr(genzahl, trainername, statsList):

  tablename = "Trainer" + str(genzahl) + "Gen"
  statsList = celltoArr2(tablename, trainername, statsList)
  return statsList

def movetoArr(moveName,moveList):
  moveList = linetoArr2("Moves", moveName, moveList)
  return moveList

def getalldb(tabelle,list):
  conn = sqlite3.connect('PokeData.db')
  cursor = conn.cursor()
  cursor.execute("SELECT * FROM " + tabelle )
  result = cursor.fetchall()

  return result



def linetoArr(tabelle,x, trainerName, list):
  conn = sqlite3.connect('PokeData.db')
  cursor = conn.cursor()
  cursor.execute("SELECT * FROM " + tabelle + " WHERE "+x+" =\"" +
                 trainerName+"\"")
  result = cursor.fetchall()
  conn.close()
  data_list = []
  for result1 in result:
    data_list.append(result1)
  return data_list

def linetoArr2(tabelle, trainerName, list):
    result2 = []
    conn = sqlite3.connect('PokeData.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM " + tabelle + " WHERE Name =\"" + trainerName+"\"")
    result = cursor.fetchall()
    ras = [tupel_to_string2(t) for t in result]
    parts = tupel_to_string(ras) 
    parts= parts.split()
    for word in parts:
      if word.isdigit():
          result2.append(int(word))
      elif word == "" or word == "—" or word == "None":
        result2.append(0)
      else:
        result2.append(word)
    list = result2
    conn.close()
    return list
def celltoArr(tabelle, spalte, trainerID, list):
  conn = sqlite3.connect('PokeData.db')
  cursor = conn.cursor()

  cursor.execute(
      str("SELECT " + spalte + " FROM " + tabelle + " WHERE TrainerID =" +
          trainerID))
  result = cursor.fetchall()
  ras = [tupel_to_string(t) for t in result]
  for i in range(len(ras)):
    list[i] = ras[i]
  conn.close()
  return list


def celltoArr2(tabelle, trainerID, list):
  conn = sqlite3.connect('PokeData.db')
  cursor = conn.cursor()
  cursor.execute("SELECT Pokemon FROM " + tabelle + " Where TrainerName = \"" +
                 trainerID + "\"")
  result = cursor.fetchone()
  ras = tupel_to_string(result)
  list = ras.split()

  cursor.close()
  conn.close()
  return list


def celltoArr3(tabelle, species, list):
  global stattemplate
  conn = sqlite3.connect('PokeData.db')
  cursor = conn.cursor()
  for i in range(len(stattemplate)):
    cursor.execute("SELECT \"" + stattemplate[i] + "\" FROM " + tabelle +
                   " Where Species = \"" + species + "\"")
    result = cursor.fetchone()
    if i ==0 or i == 1:
      list[i] =tupel_to_string(result)
    else:
      list[i] = tupel_to_integer(result)
  cursor.close()
  conn.close()
  return list

def getcell(tabelle, x,y,ywert): #z.B getcell("Trainer"+str(gen)+"Gen","Lose","TrainerName",Spielerliste[i])
  conn = sqlite3.connect('PokeData.db')
  cursor = conn.cursor()
  cursor.execute("SELECT \""+x +"\" FROM " + tabelle + " Where "+y +" = \"" +
                 ywert + "\"")  
  result = cursor.fetchone()
  cursor.close()
  conn.close()
  return result[0]
def celltoArr4(tabelle, trainerID, list):
  conn = sqlite3.connect('PokeData.db')
  cursor = conn.cursor()
  cursor.execute("SELECT Pokemon FROM " + tabelle + " Where TrainerName = \"" +
                 trainerID + "\"")
  result = cursor.fetchone()
  ras = tupel_to_string(result)
  list = ras.split()

  cursor.close()
  conn.close()
  return list

def coltoArr(tabelle, spalte, list):
  conn = sqlite3.connect('PokeData.db')
  cursor = conn.cursor()
  cursor.execute("SELECT " + spalte + " FROM " + tabelle)
  result = cursor.fetchall()
  ras = [tupel_to_string(t) for t in result]
  for i in range(len(ras)):
    list.append( ras[i])
  conn.close()
  return list
testlist =[]
#coltoArr("Trainer1Gen","Pokemon",testlist)

def coltoArr5(tabelle, spalte, list):
  conn = sqlite3.connect('PokeData.db')
  cursor = conn.cursor()
  cursor.execute("SELECT " + spalte + " FROM " + tabelle + " ORDER BY TrainerID ASC")
  result = cursor.fetchall()
  ras = [tupel_to_string(t) for t in result]
  for i in range(len(ras)):
    list.append( ras[i])
  conn.close()
  return list
#par slp gif brn frz ko cnf fln lch lov crs
def aftereffect(attackmove1,attackmove2,stat1,stat2,pokeval1,pokeval2,pokestat1,pokestat2,healthbar1,healthbar2 ,dmg,zahl):
  global miss
  if miss == False:
    return
  if random.random() *100 < attackmove1[0][5]:
    doeffect(attackmove1,attackmove2,stat1,stat2,pokeval1,pokeval2,pokestat1,pokestat2,healthbar1,healthbar2,dmg,zahl)

def doeffect(attackmove1,attackmove2,stat1,stat2,pokeval1,pokeval2,pokestat1,pokestat2,healthbar1,healthbar2,dmg,zahl ):
  global sun
  global sandstorm
  global hail
  global rain
  global slp1
  global slp2
  global hyp1
  global hyp2
  for i in range(11): #1-30 Statusveränderungen
    if attackmove1[0][6] ==1+i:
      pokestat2[i] = True
      return
  if (attackmove1[0][6] ==15 and slp1 ==0 )or (attackmove1[0][6] ==15 and slp2 == 0):
    if zahl == 1:
        slp1=random.randint(1, 7)
    elif zahl ==2:
        slp2=random.randint(1, 7)
  if (attackmove1[0][6] ==16 and hyp1) or (attackmove1[0][6] ==15 and hyp2 == 0):
    if zahl == 1:
        hyp1=2
    elif zahl ==2:
        hyp2=2      
     
  for i in range(7):#atk def spatk spdef init eva acc crt 
    if attackmove1[0][6] ==i+30: # 30 - 70 Statuswerte
      pokeval1[i] += attackmove1[0][7]
      if pokeval1[i] >7:
        pokeval1[i] == 6
      if pokeval1[i] <-6:
        pokeval1[i] == 0
  for i in range(7):#atk def spatk spdef init eva acc crt 
    if attackmove1[0][6] ==i+50:
      if pokeval2[i] >7:
        pokeval2[i] == 6
      if pokeval2[i] <-6:
        pokeval2[i] == 0
  if attackmove1[0][6] == 71: #absorber
    healthbar1[0] +=math.ceil(dmg/2)
    if healthbar1[0] > stats2[0].hp*2+110:
      healthbar1[0] = stats2[0].hp*2+110
  if attackmove1[0][6] ==72: # Fuchtler
    pokestat1[6] = True
  if attackmove1[0][6] == 73: # Recoil
    healthbar1[0] -= math.ceil(dmg/3)
  if attackmove1[0][6] == 74: # KO Attacken
    healthbar2[0] = 0
  if attackmove1[0][6] == 87: # fuck Hpyerbeam
    pokeval1[11] = True
  if attackmove1[0][6] == 76: #sunday
    rain,sandstorm,hail =0
    sun = 8
  if attackmove1[0][6] == 77: #sunday
    rain,sandstorm,sun =0
    hail = 8
  if attackmove1[0][6] == 78: #sunday
    rain,sun,hail =0
    sandstorm = 8
  if attackmove1[0][6] == 79: #sunday
    sun,sandstorm,hail =0
    rain = 8
  if attackmove1[0][6] == 80: # true Damage
    healthbar2[0] - attackmove1[0][7]
  if attackmove1[0][6] == 81: # Flail
    if healthbar1[0] >= 68.75:
        healthbar2[0]- 20
    elif 35.42 <= healthbar1[0] < 68.75:
        healthbar2[0]- 40
    elif 20.83 <= healthbar1[0] < 35.42:
        healthbar2[0]- 80
    elif 10.42 <= healthbar1[0] < 20.83:
        healthbar2[0]- 100
    elif 4.17 <= healthbar1[0] < 10.42:
        healthbar2[0]- 150
    else:
        healthbar2[0]- 200
  if attackmove1[0][6] == 82: # Swagger
    pokeval2[0] + 2
    if pokeval2[0] >7:
      pokeval2[0] == 6
  if attackmove1[0][6] == 83: # Flatter
    pokeval2[2] + 2
    if pokeval2[2] >7:
      pokeval2[2] == 6
  if attackmove1[0][6] == 84:
    ps = math.ceil((healthbar2[0] + healthbar1[0])/2)
    healthbar1[0] = ps
    if ps > stat1[0].hp*2+110:
      healthbar1[0] = stat1[0].hp*2+110
    healthbar2[0] = ps
    if ps > stat2[0].hp*2+110:
      healthbar2[0] = stat2[0].hp*2+110
  if attackmove1[0][6] == 85: #Silberhauch
    for i in range (5):
      pokeval1[i] +=1
      if pokeval1[i]<7:
        pokeval1[i] =6
  if attackmove1[0][6] == 86: # Erholung
    pokestat1[1] = True
    healthbar1[0] = stat2[0].hp*2+110
  if attackmove1[0][6] == 87: # Explosion Finale
    healthbar1[0] = 0

def blockPrint():
    sys.stdout = open(os.devnull, 'w')

def enablePrint():
    sys.stdout = sys.__stdout__




def getProfile(id):
  profile = [] #[(347156882374262795, 'Tony', 2, 'acetrainerf', 0, None, None)]
  profile2 = []#[(216, 'acetrainerf', 'ELEKID SKIPLOOM UNOWN CHINCHOU', 0, 0, None, None, 5000000, None, None, 1366, 1)]
  profile3 =[] #[[('ELEKID', 'Elekid', 'Electric', '', '360', 45, 63, 37, 65, 55, 95, 255, 1, None, None, None, None, None...
  fourpokemon = []
  profile = linetoArr("Spieler", "NutzerID",str(id),profile)
  profile2 = linetoArr("Trainer"+str(profile[0][2])+"Gen", "Trainername",profile[0][3],profile2)
  fourpokemon = profile2[0][2].split()
  for i in range(len(fourpokemon)):
    profile3.append(linetoArr("PokeStats"+str(profile[0][2]), "SPECIES",fourpokemon[i], profile3 ))
  print(profile)
  print(profile2)
  print(profile3)
  return profile, profile2, profile3


def makestats2():  
  tempmove = []
  j = -1
  temp = []
  coltoArr("PokeStats","Species",temp)
  #temp2 = []
  for i in range(len(temp)):
    f = 0
    j =j +1
    for key, value in moveList3:
      f +=1
      if key == temp[i]:
        #print(temp[i])
        #print(i)
        #print(j)
        #print(f)
        temp2 = moveList3[f-1][1][-4:]
        wintodb("PokeStats","Move1",temp2[0],"Species",temp[i])
        wintodb("PokeStats","Move2",temp2[1],"Species",temp[i])
        wintodb("PokeStats","Move3",temp2[2],"Species",temp[i])
        wintodb("PokeStats","Move4",temp2[3],"Species",temp[i])
        #print(moveList3[f-1][1][-4:]) #def wintodb(Tabelle,x,xwert, y,ywert):
makestats2()
def change(befehl,id):
  p1 = [] #[(347156882374262795, 'Tony', 2, 'acetrainerf', 0, None, None)]
  p2 = []#[(216, 'acetrainerf', 'ELEKID SKIPLOOM UNOWN CHINCHOU', 0, 0, None, None, 5000000, None, None, 1366, 1)]
  p3 =[] #[[('ELEKID', 'Elekid', 'Electric', '', '360', 45, 63, 37, 65, 55, 95, 255, 1, None, None, None, None, None...
  p1,p2,p3 = getProfile(id)
  ba = [] #befehlarray
  ba = befehl.split()
  for i in range(4):
    if ba[0] == "get" and ba[2]=="move"+str(i): # syntax eingehalten? get ABRA move MEGA_DRAIN
      if ba[1] == p3[0][0][0] or ba[1] == p3[1][0][0] or ba[1] == p3[2][0][0] or ba[1] == p3[3][0][0]: #ist das pokemon im Kader?
        if islearnable2(ba[1],ba[3]):
          wintodb("PokeStats"+str(p1[2]),"Move"+str(i),ba[3],"Species",ba[1])
      else:
        print("Fehler")

    if ba[0] == "get" and ba[2]=="position" and ba[3] ==str(i-1): #get gyarados position 1
      if ba[1] == p3[0][0][0] or ba[1] == p3[1][0][0] or ba[1] == p3[2][0][0] or ba[1] == p3[3][0][0]: #ist das pokemon im Kader?
        changepos(ba[1],i-1,p1[2],p1[3],p2[2])#changepos("ABRA",0,1,"crushgirl","SLOWPOKE SQUIRTLE ABRA DODUO")
        pass
      else:
        print("Fehler")

  if ba[0] == "get" and ba[2]=="strat": # syntax eingehalten? get ABRA strat 2
    if ba[1] == p3[0][0][0] or ba[1] == p3[1][0][0] or ba[1] == p3[2][0][0] or ba[1] == p3[3][0][0]: #ist das pokemon im Kader?
      wintodb("PokeStats"+str(p1[2]),"Strat",ba[3],"Species",ba[1])
    else:
      print("Fehler")
    pass
  
  if ba[0] == "scout" and ba[2]=="give": # syntax eingehalten? scout ABRA give PIKACHU
    if ba[3] == p3[0][0][0] or ba[1] == p3[1][0][0] or ba[1] == p3[2][0][0] or ba[1] == p3[3][0][0] or ba[1] !=ba[3]: #ist das pokemon im Kader?
      for i in range(len(moveList3)):
        if ba[1] in moveList3[i]:
          wintodb("PokeStats"+str(p1[2]),"TransferWunschliste",ba[3],"NutzerID",p1[0])
          wintodb("PokeStats"+str(p1[2]),"PokeAbgänger",ba[1],"NutzerID",p1[0])
          
          break
        else:
          print(ba[1] + " wurde nicht gefunden")
          break        
    else:
      print("Fehler")
    pass


def changepos(pkm,pos,gen,trainer,kader):
  temp = []
  temp = kader.split()
  if pkm in temp:
    temp.remove(pkm)
    temp.insert(pos,pkm)
  temp2 = " ".join(temp)
  wintodb("Trainer"+str(gen)+"Gen","Pokemon",str(temp2),"TrainerName",trainer)






 #def wintodb(Tabelle,x,xwert, y,ywert):
        
        #wintodb("SpieltagGen1l1","Field1","1","ROWID",str(2))
#onematch("Liga 1","birdkeeper",3,"psychicm",1)
#def coltoArr(tabelle, spalte,  list):





#getProfile(347156882374262795)
#change("hai hao",347156882374262795)
#wintodb("SpieltagGen1l1","Field1","1","ROWID",str(2))
#wintodb("Spieler","PokeAbgänger","s","ROWID",str(2))
def islearnable(pkm,move):
  for i in range(len(moveList3)):
    if pkm in moveList3[i]:
      if move in moveList3[i][1]:
        return True
      else:
        print("false")

def islearnable2(pkm,move):

  for i in range(len(moveList3)):
    if pkm in moveList3[i]:
      if move in moveList3[i][1]:
        return True
  for i in range(len(moveList2)):
    if pkm in moveList2[i]:
      if move in moveList2[i][1]:
        return True

  for i in range(len(moveList1)):
    if pkm in moveList1[i]:
      if move in moveList1[i][1]:
        return True
      else:
        return False

#print(islearnable2("ABRA","MEG"))
def addtxt(satz,asp):
  global player1
  global player2
  if player1 in asp:
    file_path = str(player1)+".txt"
    with open("hallo.txt", "w") as file:
      file.write(satz)

def addtxt2(satz):
  file_path = "test.txt"
  with open(file_path, "a") as file:  # Verwende "a" (append) statt "w" (write)
    file.write(satz + "\n")  

def clrtxt():
  file_path = "test.txt"
  with open(file_path, "w") as file:
    file.truncate()


