class Pokemon:
  def __init__(self, species, name,type1,type2, hp, atk, dfn,spatk,spdfn,spd,win,lose, winrate, geld,win10,trainer):
    self.species = species
    self.name = name
    self.type1 = type1
    self.type2 = type2
    self.hp = hp
    self.atk = atk
    self.dfn = dfn
    self.spatk = spatk
    self.spdfn = spdfn
    self.spd = spd
    self.win = win
    self.lose = lose
    self.winrate = winrate
    self.geld = geld
    self.win10 = win10
    self.trainer = trainer
        