from typing_extensions import Doc

from BattleTeam import BattleTeam
import sqlite3
from Game_Init import tupel_to_string
from Game_Init import tupel_to_string2
from Move import Move
from Stat import Stat
from PokeLib3 import moveList3


cattack = False
cchange = False
confu = False
par = False
miss = False
death = False
r = 0
pokemon = []
team1moves = []
team2moves = []
moveset1 = []
moveset2 = []
pokemonstatus1 = []
pokemonstatus2 = []

healthbar1=[]
healthbar2=[]
defeat = False
stats1 = [] 
stats2 = []
stattemplate = ["HP", "Attack", "Defense", "Sp.Attack", "Sp.Defense", "Speed","Strat"]
onelose = False


def getData(trainer1, trainer2, gen):
  global defeat
  global stats1
  global stats2
  global moveset
  global team1moves
  global team2moves
  pokenames1 = []
  pokenames2 = []
  pokenames1 = kadertoArr(gen, trainer1, pokenames1)
  pokenames2 = kadertoArr(gen, trainer2, pokenames2)

  stats1 = makestats(pokenames1, gen,stats1)
  stats2 = makestats(pokenames2, gen,stats2)
  #makestats()


  for i in range(len(stats1)):
    team1moves.append([])
    if len(stats1[i].m1) != 0:
      team1moves[i].append(Move("","",0,0,0,0,0,0))
      #print(movetoArr(stats1[i].m1, team1moves[i]))
      
      team1moves[i][0]=movetoArr(stats1[i].m1, team1moves[i])
      
      #print(team1moves[0])
    if len(stats1[i].m2) != 0:
      team1moves[i].append(Move("","",0,0,0,0,0,0))
      team1moves[i][1]=movetoArr(stats1[i].m2, team1moves[i])
    if len(stats1[i].m3) != 0:
      team1moves[i].append(Move("","",0,0,0,0,0,0))
      team1moves[i][2]=movetoArr(stats1[i].m3, team1moves[i])
      

    if len(stats1[i].m4) != 0:
      team1moves[i].append(Move("","",0,0,0,0,0,0))
      team1moves[i][3]=movetoArr(stats1[i].m4, team1moves[i])
  print(team1moves[0][1][0])
  print(team1moves[0][1][1])
  print(team1moves[0][1][2])
  
def makestats(pokenames, gen,statslist):  
  tempstat = [0, 0, 0, 0, 0, 0,0]
  tempmove = ["","","",""]
  for i in range(len(pokenames)):
    statslist.append(Stat(pokenames[i], 0, 0, 0, 0, 0, 0 , 0, "","","",""))
    stattoArr(gen, pokenames[i], tempstat)
    statslist[i].hp = tempstat[0]
    statslist[i].attack = tempstat[1]
    statslist[i].defense = tempstat[2]
    statslist[i].spattack = tempstat[3]
    statslist[i].spdefense = tempstat[4]
    statslist[i].speed = tempstat[5]
    statslist[i].strat = tempstat[6]

    searchKey = pokenames[i]
    j = -1
    for key, value in moveList3:
      j =j +1
      if key == searchKey:
        anz = moveList3[j][1][-4:]
        for k in range (len(anz)):
          tempmove[k] = anz[k]

    statslist[i].m1 = tempmove[0]
    statslist[i].m2 = tempmove[1]
    statslist[i].m3 = tempmove[2]
    statslist[i].m4 = tempmove[3]
  #stats2 = Stat(trainer1, 0, 0, 0, 0, 0, 0, [])
  #print(len(stats1))
  #print(stats1[0].m1)

  return statslist

def stattoArr(genzahl, pokemon, statsList):
  tablename = "PokeStats" + str(genzahl)
  statsList = celltoArr3(tablename, pokemon, statsList)
  return statsList


def kadertoArr(genzahl, trainername, statsList):

  tablename = "Trainer" + str(genzahl) + "Gen"
  statsList = celltoArr2(tablename, trainername, statsList)
  return statsList

def movetoArr(moveName,moveList):
  moveList = linetoArr2("Moves", moveName, moveList)
  return moveList

def linetoArr(tabelle, trainerName, list):
  conn = sqlite3.connect('PokeData.db')
  cursor = conn.cursor()
  cursor.execute("SELECT * FROM " + tabelle + " WHERE TrainerName =\"" +
                 trainerName+"\"")
  result = cursor.fetchall()
  ras = [tupel_to_string(t) for t in result]
  for i in range(len(ras)):
    list[i] = ras[i]
  conn.close()
  return list

def linetoArr2(tabelle, trainerName, list):
    result2 = []
    conn = sqlite3.connect('PokeData.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM " + tabelle + " WHERE Name =\"" + trainerName+"\"")
    result = cursor.fetchall()
    ras = [tupel_to_string2(t) for t in result]
    parts = tupel_to_string(ras) 
    parts= parts.split()
    for word in parts:
      if word.isdigit():
          result2.append(int(word))
      elif word == "" or word == "—" or word == "None":
        result2.append(0)
      else:
        result2.append(word)
    list = result2
    #print(list)
    conn.close()
    return list
def celltoArr(tabelle, spalte, trainerID, list):
  conn = sqlite3.connect('PokeData.db')
  cursor = conn.cursor()

  cursor.execute(
      str("SELECT " + spalte + " FROM " + tabelle + " WHERE TrainerID =" +
          trainerID))
  result = cursor.fetchall()
  ras = [tupel_to_string(t) for t in result]
  for i in range(len(ras)):
    list[i] = ras[i]
  conn.close()
  return list


def celltoArr2(tabelle, trainerID, list):
  conn = sqlite3.connect('PokeData.db')
  cursor = conn.cursor()
  cursor.execute("SELECT Pokemon FROM " + tabelle + " Where TrainerName = \"" +
                 trainerID + "\"")
  result = cursor.fetchone()
  #print(result)
  ras = tupel_to_string(result)
  list = ras.split()
  
  cursor.close()
  conn.close()
  return list


def celltoArr3(tabelle, species, list):
  global stattemplate
  conn = sqlite3.connect('PokeData.db')
  cursor = conn.cursor()
  for i in range(len(stattemplate)):
    cursor.execute("SELECT \"" + stattemplate[i] + "\" FROM " + tabelle +
                   " Where Species = \"" + species + "\"")
    result = cursor.fetchone()
    
    list[i] =tupel_to_integer(result)
    
  cursor.close()
  conn.close()
  return list

def celltoArr4(tabelle, trainerID, list):
  conn = sqlite3.connect('PokeData.db')
  cursor = conn.cursor()
  cursor.execute("SELECT Pokemon FROM " + tabelle + " Where TrainerName = \"" +
                 trainerID + "\"")
  result = cursor.fetchone()
  ras = tupel_to_string(result)
  list = ras.split()

  cursor.close()
  conn.close()
  return list

def coltoArr(tabelle, spalte, trainerID, list):
  conn = sqlite3.connect('PokeData.db')
  cursor = conn.cursor()
  cursor.execute("SELECT " + spalte + " FROM " + tabelle)
  result = cursor.fetchall()
  ras = [tupel_to_string(t) for t in result]
  for i in range(len(ras)):
    list[i] = ras[i]
  conn.close()
  return list


def none():
  global healthbar1
  global healthbar2


  Trainer1 = BattleTeam(2, 2)
  Trainer1 = BattleTeam(3, 3)
  print("")

def fightmatch(trainer1,trainer2,gen): # Trainer Name 1 und 2 und Genzahl
  global onelose # Sind alle HP = 0?
  global r # Rundenzahl
  while True: # Scheife solange es noch Pokemon gibt
    while True: # Schleife 2 fightstep() pro runde
      #getmove(stratID)  # get True damage, get Prio wert
      #choseprio() # Get True Prio 
      fightstep() # Fight, highest Prio first
      if r>=2:
        break
    if onelose:
      break

def getMove(stratID):
  if stratID == 1:
    truedamage = 0
    print(team1moves[0][0][1]) #get Typ Attack
    print(team1moves[0][0][2]) #get Power
    print(team1moves[0][1][1]) #get Typ Attack
    print(team1moves[0][1][2]) #get Power
    print(team1moves[0][2][1]) #get Typ Attack
    print(team1moves[0][2][2]) #get Power
    print(team1moves[0][3][1]) #get Typ Attack
    print(team1moves[0][3][2]) #get Power
      
    print(stats1[0].attack) #get Defense Deffender
    print(stats1[0].defense) #get Defense Deffender
    print(stats1[0].spattack) #get Defense Deffender
    print(stats1[0].spdefense) #get Defense Deffender


  

def tD(pw,type):
  spec = ["Normal","Fighting","Flying","Poison","Ground","Rock","Bug","Ghost","Steel"]
  phy =["Fire","Water","Grass","Electric","Psychic","Ice","Dragon","Dark"]

  if type in phy:
    return ((42*stats1[0].attack/stats1[0].defense*pw)/50)+2
  if type in spec:
    return ((42*stats1[0].spattack/stats1[0].spdefense*pw)/50)+2


  
def fightstep():
  global r
  if cattack:
    attack(20,1,2) #StratID
    if death:
      r = r + 1
      return
  elif cchange:
    change()
  afterDamage()

def fightphase(pokemon, moves):
  global r
  while True:
    #getmoves()
    fightstep()
    if r >= 2:
      break
  r = 0
def attack(strat,sp, sv):#strat = strategie sp = Statusprobleme sv = Statusveränderungen
  hitormiss = 1 # hit = 1, miss = 0, burn = 0,5
  afterdamage = 0
  if confu:
    confudamage()
  if par:
    
    if miss:
      takeMissDamage()
  movechoice(strat)
  
  hp_dmg()

def movechoice(strat):
  print("")

def hp_dmg():
  print("")


def change():
  print("change Pokemon")


def checkifdead():
  hp = 0
  if (hp >= 0):
    death = True


def takeMissDamage():
  print("hi")


def takeDamage():
  print("hi")


def afterDamage():
  print("hi")


def confudamage():
  print("hi")

def tupel_to_integer(tupel):
  return int(''.join(str(e) for e in tupel))