class BattleTeam:
  def __init__(self, name,pokeset):
      self.name = name
      self.pokeset = pokeset

