
zahl = "hall"
def showTemplate():
    return "Winrate last "+zahl 



# Bearbeiten der Daten
# Hier können Sie die Daten bearbeiten, wie Sie möchten

# Exportieren der Daten in ein anderes Format
# Hier können Sie die Daten in ein anderes Format exportieren, wie z.B. CSV
#pyexcel_ods.save_data('path/to/your/exported/file.csv', data)